-------1A
select customer.customer_id,first_name,last_name, sum(payment.amount)
from customer
join payment
on customer.customer_id = payment.customer_id
group by customer.customer_id
order by customer_id

-------1B
select customer.customer_id,first_name,last_name, avg(payment.amount)
from customer
join payment
on customer.customer_id = payment.customer_id
group by customer.customer_id
having avg(amount)<3
order by customer_id

-------2A
SELECT first_name,last_name,distict FROM customer
INNER JOIN address
ON customer.address_id=address.address_id

-------2B
SELECT customer.customer_id,SUM(payment.amount) FROM customer
join payment
on customer.customer_id=payment.customer_id
GROUP BY customer.customer_id
HAVING sum(amount)>100

-------3A
select customer.customer_id,first_name,last_name,sum(payment.amount) 
from customer
join payment
on customer.customer_id=payment.customer_id
group by customer.customer_id
having sum(amount)>=200

