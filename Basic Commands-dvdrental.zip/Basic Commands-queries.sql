-------1A
select title,replacement_cost from film
where replacement_cost between 15.99 and 20.99
and title like 'S%' 
or title like 'T%'

-------1B
select film_id,title from film
where length < 100
and replacement_cost between 15.99 and 20.99
and rating in ('G','PG','PG-13')

-------3A
SELECT amount FROM payment
WHERE customer_id=514

-------3B
SELECT COUNT(rating) FROM film
WHERE rating='R

