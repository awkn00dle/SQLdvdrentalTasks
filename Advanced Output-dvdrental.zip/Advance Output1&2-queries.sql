-------Adv Output 1
------------- 1 
select concat(title,'-',description) as title_description from film

------------- 2
select title,rental_rate,
case 
	when rental_rate > 2 then 'Expensive'
	when rental_rate = 2 then 'Average'
	when rental_rate < 2 then 'Cheap'
end as length_analysis
from film

------------- 3
select staff_id, sum(amount),
case
	when sum(amount) = 25000 then 'Quota Met'
	when sum(amount) > 25000 then 'Quota Met'
	when sum(amount) < 25000 then 'Quota Unmet'
end as quota_rating
from payment
group by staff_id
order by staff_id asc





-----------------------------------------Adv Output 2
--------------------------------------- 1
-----Create a backup table for movies
create table movies_backup as 
select * from movies

-----Change ‘-‘ to ‘not given’ for director column
UPDATE movies_backup
SET director = 'not given'
where director = '-'

-----Change ‘-‘ to ‘not given’ for country column
UPDATE movies_backup
SET country = 'not given'
where country = '-'

----- View updated movies_backup
select show_id,director,country
from movies_backup

--------------------------------------- 2
----- Create new column ‘month_added’ as INTEGER as type
ALTER TABLE movies_backup
ADD COLUMN month_added INTEGER;

----- Update month_added as an extraction from date_added 
UPDATE movies_backup
SET month_added = EXTRACT(month FROM date_added)

----- View movies_backup table
select date_added, month_added as month_added 
from movies_backup

--------------------------------------- 3
select show_id,duration,
case 
	when duration ilike '%Season%' then 'TV series'
else 'Movie'
end as title_type
from movies_backup

--------------------------------------- 4
select distinct show_id,
	case when director = '-' then 'n/a' else initcap(director) 
	end as director_initcap,
	case when country = '-' then 'n/a' else initcap(country) 
	end as country_initcap,
	concat(rating_1,'-',rating_2) as rating,
	case when duration ilike '%Season%' then 'TV series' else 'Movie' end as title_type,
	to_char(date_added, 'Mon') as month_added
from movies_backup

--------------------------------------- 5
create table cleaned_movies as
select distinct show_id,
	case when director = '-' then 'n/a' else initcap(director) 
	end as director_initcap,
	case when country = '-' then 'n/a' else initcap(country) 
	end as country_initcap,
	concat(rating_1,'-',rating_2) as rating,
	case when duration ilike '%Season%' then 'TV series' else 'Movie' end as title_type,
	to_char(date_added, 'Mon') as month_added
from movies_backup

--------------------------------------- 6
select month_added, count(show_id)
from cleaned_movies
group by month_added
order by count(show_id) desc

--------------------------------------- 7
select title_type, count(show_id)
from cleaned_movies
group by title_type
